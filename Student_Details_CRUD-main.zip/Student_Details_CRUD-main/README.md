# Student_Details_CRUD
<img src="https://github.com/user-attachments/assets/da85a031-1348-41e8-b9b5-7ee7f3d50859"/>
<img src="https://github.com/user-attachments/assets/420723a2-5448-46f2-bc99-aeeb654203b9"/>
<img src="https://github.com/user-attachments/assets/40d7a555-12bc-4153-a04b-de4aca006ea8"/>
